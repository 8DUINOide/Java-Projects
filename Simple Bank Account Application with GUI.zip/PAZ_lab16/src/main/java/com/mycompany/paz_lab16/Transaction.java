/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.paz_lab16;

/**
 *
 * @author Admin
 */
public class Transaction {
  
    private double amount;
    private String transactionType;
  
    
    public Transaction() {
     
        this.amount = 21955.67;
        this.transactionType = "withdraw";
        
    }
    public void setAmount(double amount)
    {
        this.amount = amount;
    }
    public void setTransactionType(String transactionType)
    {
        this.transactionType = transactionType;
    }

    public double getAmount()
    {
        return amount;
    }
    public String getTransactionType()
    {
        return transactionType;
    }
  
    public String toString()
    {
        return "\nAmount: " +amount +
                "\nTransaction Type: " + transactionType;
    }
    
     
}