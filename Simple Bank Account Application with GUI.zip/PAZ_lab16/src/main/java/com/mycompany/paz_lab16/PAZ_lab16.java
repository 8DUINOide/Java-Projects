/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.paz_lab16;

/**
 *
 * @author Admin
 */
public class PAZ_lab16 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
