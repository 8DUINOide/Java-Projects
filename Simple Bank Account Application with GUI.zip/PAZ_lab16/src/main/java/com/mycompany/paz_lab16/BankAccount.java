/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.paz_lab16;

/**
 *
 * @author Admin
 */
public class BankAccount {
    private String accountName;
    private String contactNumber;
    private String emailAddress;
    private String accountType;
    private double totalBalance;
   
    
    
    public BankAccount(){
        this.accountName= "AL";
        this.contactNumber="09772153941";
        this.emailAddress="afpaz@gbox.adnu.edu.ph";
        this.accountType= "savings";
        this.totalBalance = 0;
    }
    
    public void setAccountName(String accountName) {
        this.accountName= accountName;
    }
    
    public void setContactNumber(String contactNumber) {
        this.contactNumber= contactNumber;
    }
    
    public void setEmailAddress(String emailAddress){
        this.emailAddress= emailAddress;
    }
      public void setAccountType(String accountType){
        this.accountType= accountType;
    }
     public void setTotalBalance(double totalBalance){
        this.totalBalance= totalBalance;
    }
    
    public String getAccountName() {
        return accountName;
    }
    
    public String getContactNumber(){
        return contactNumber;
    }
    
    public String getEmailAddress(){
        return emailAddress;
    }
     public String getAccountType(){
        return accountType;
    }
     public double getTotalBalance(String transactionType,double amount){
          {
        // Update totalBalance based on transactionType
        if ("deposit".equalsIgnoreCase(transactionType)) {
           totalBalance += amount;
        } else if ("withdraw".equalsIgnoreCase(transactionType)) {
            totalBalance -= amount;
        } 
    }
        return totalBalance;
    }
    
    public String toString(){
        return "\nBank Account details: " + "\nBank account name: " + 
        accountName + "\nContact Number: "+ contactNumber + "\nEmail Address: " +
        emailAddress+"\nTotal Balance: " + totalBalance + "\nAccount Type: " + accountType;
    }
}