package com.mycompany.paz_lab17;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class BankAccount {
     private String name;
    private String accountType;
    private String emailAddress;
    private String contactNumber;
    private int count;
    private double balance;
    private Transaction [] transactions;

    
    public BankAccount() {
        name = "Juan dela Cruz";
        accountType = "";
        emailAddress = "jdlc@gmail.com";
        contactNumber = "09123456789";
        balance = 0.00;
        transactions = new Transaction [10];
        count = 0;
    }
    
    public void setname(String name){
        this.name = name;
    }
    
    public void setaccountType(String accountType){
        this.accountType = accountType;
    }
    
    public void setemailAddress(String emailAddress){
        this.emailAddress = emailAddress;
    } 
    
    public void setcontactNumber(String contactNumber){
        this.contactNumber = contactNumber;
    }
    
    public void setbalance(double balance){
        this.balance = balance;
    }
    
    public String getname(){
        return name;
    }
    
    public String getaccountType(){
        return accountType;
    }
    
    public String getemailAddress(){
        return emailAddress;
    }
    
    public String getcontactNumber(){
        return contactNumber;
    }
    
    public double getbalance(double amount,String type){
        if (type.equalsIgnoreCase("withdraw")){
            balance -= amount;
        } else if (type.equalsIgnoreCase("deposit")){
            balance += amount;
        }   
        
        return balance;
    }  
    
    public double Balance () {
        return balance;
    }
    
    public Transaction getTransaction(int index)
    {
        return transactions[index];
    }
    
    public void setcount (int count) {
        this.count = count;
    }
    
     public int getcount () {
        return count;
    }
    
    public void addTransaction(double balance, double amount, String transactionType)
    {
        transactions[count] = new Transaction(balance, amount, transactionType);
        count++;
       
    }
    
    public String toString(){
        return "Student Details:\nName:\t" + name +
                "\nEmail Address:\t" + emailAddress +
                "\nContact Number:\t" + contactNumber +
                "\nAccount Type:\t" + accountType +
                "\nBalance:\t" + balance;
    }
}
