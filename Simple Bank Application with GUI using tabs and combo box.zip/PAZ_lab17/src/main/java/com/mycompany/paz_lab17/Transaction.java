/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.paz_lab17;

/**
 *
 * @author Admin
 */
public class Transaction {
     private double balance;
    private double amount;
    private String transactionType;
    
    public Transaction () {
        amount = 1.00;
        transactionType = "";
    }
    
    public Transaction (double balance, double amount, String transactionType) {
        this.amount = amount;
        this.transactionType = transactionType;
        this.balance = balance;
    }
    
    public void setamount (double amount) {
        this.amount = amount;
    }
    
    public void settransactionType (String transactionType) {
        this.transactionType = transactionType;
    }
    
    public double getamount () {
        return amount;
    }
    
    public String gettransactionType () {
        return transactionType;
    }
    
   
}

