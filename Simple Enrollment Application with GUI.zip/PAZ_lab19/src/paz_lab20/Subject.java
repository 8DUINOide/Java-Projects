/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paz_lab20;

/**
 *
 * @author CISCOLAB
 */
public class Subject {
  private Student[] students;
    private Teacher teachers;
    private String subjectName;
    private int numberOfStudents;
    private int numberOfUnits;
    private int maxCount;
    private int studentCount;

     public Subject()
    {
        students= new Student[39];
        teachers= new Teacher();
        subjectName = "Math";
        numberOfStudents = 20;
        numberOfUnits = 20;
        maxCount = 10;
        studentCount = 0;
    }
         public Subject(String subjectName, int numberOfUnits)
    {
        students= new Student[39];
        teachers= new Teacher();
        this.subjectName = subjectName;  
        this.numberOfUnits = numberOfUnits;  
        
    }
        public void setNumberOfUnits (int numberOfUnits) {
        this.numberOfUnits = numberOfUnits;
        teachers.setNumberOfUnits(teachers.getNumberOfUnits() + numberOfUnits);
        for (int i=0; i<studentCount; i++) {
            students[i].setNumberOfUnits(students[i].getNumberOfUnits() + numberOfUnits);
        }  
    }
      public void setSubjectsName(String subjectsName)
    {
        this.subjectName = subjectName;
    }
     public void setNumberOfStudents(int numberOfStudents)
    {
        this.numberOfStudents = numberOfStudents;
    }
   public String getSubjectsName()
    {
        return subjectName;
    }
    public int getNumberOfStudents()
    {
        return numberOfStudents;
    }
   public int getNumberOfUnits()
    {
        return numberOfUnits;
    }
  public void setTeachersInfo(String name, String emailAddress, String contactNumber) {
        teachers.setTeachersInfo(name, emailAddress, contactNumber);
    }
    
    public void addTeachersSalary (String specialization, double perUnitRate, int numberOfUnits) {
        teachers.setSalary(specialization, perUnitRate, getNumberOfUnits() + numberOfUnits);
    }
    
    public void addStudent (String name,String emailAddress, String contactNumber, String program, int yearLevel, int numberOfUnits) {
        students [studentCount] = new Student(name,emailAddress,contactNumber, program, yearLevel, numberOfUnits + getNumberOfUnits());
        studentCount++;
    }
    public Student getStudents(int index) {
        return students[index];
    }
    public int getStudentsCount(){
        return studentCount;
    }
    public void subjectDisplay() {
        System.out.println("--------SUBJECT INFORMATION------\nName: " + getSubjectsName() + "\nNumber of Units: " + getNumberOfUnits() + 
                "\n---------------------------------\n");
    }
    public void studentDisplay() {
        
        System.out.println("STUDENTS ENROLLED: " + studentCount);
        for(int i = 0; i<studentCount; i++) {
            System.out.println(students[i].toString());    
        }
   }
    
   public void teacherDisplay() {
       System.out.println(teachers.toString());
   }
    
}

   
    