/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paz_lab20;

/**
 *
 * @author CISCOLAB
 */
public class PAZ_lab20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Subject subjects = new Subject("Data Structures and Algorithms",5);
         
        subjects.addStudent("Al Francis Paz","afpaz@gbox.adnu.edu.ph","09772153941","BSCpE",2,3);
        subjects.addStudent("Juan Carlo Sto. Domingo","jcstodomingo@gbox.adnu.edu.ph","09876543217","BSCpE",2,4);
        subjects.setTeachersInfo("Karla Sobrevilla","ksobrevilla@gmail.com","09876543210");
        subjects.addTeachersSalary("Programming",1500.00,5);
        
        subjects.subjectDisplay();
        subjects.teacherDisplay();
        subjects.studentDisplay();    
    }
}
