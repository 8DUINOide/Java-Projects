/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paz_lab20;

/**
 *
 * @author CISCOLAB
 */
public class Student {
    private Person studentsInfo;
     private String program;
     private int yearLevel;
     private int numberOfUnits;
     private double tuitionFee;
     
    
 public Student()
    {
   
         studentsInfo = new Person();
         program = "BSCpE";
         yearLevel = 2;
         numberOfUnits = 20;
         tuitionFee = 30000;
    }
   public Student(String name,String emailAddress, String contactNumber, String program, int yearLevel, int numberOfUnits) {
        
        this.studentsInfo = new Person(name,emailAddress,contactNumber);
        this.program = program;
        this.yearLevel = yearLevel;
        this.numberOfUnits = numberOfUnits;
    }
      public void setProgram(String program)
    {
        this.program = program;
    }
     public void setYearLevel(int yearLevel)
    {
        this.yearLevel = yearLevel;
    }
      public void setNumberOfUnits(int numberOfUnits)
    {
        this.numberOfUnits = numberOfUnits;
    }
    public void setTuitionFee(double tuitionFee)
    {
        this.tuitionFee = tuitionFee;
    }
      public String getName() {
        return studentsInfo.getName();
    }
   public String getProgram()
    {
        return program;
    }
    public double getYearLevel()
    {
        return yearLevel;
    }
    public int getNumberOfUnits()
    {
        return numberOfUnits;
    }
    public double getTuitionFee()
    {
        tuitionFee = getNumberOfUnits()*1500;
        return tuitionFee;
    }

 public String toString()
    {
        return "\nName: " + studentsInfo.getName() + "\nEmail Address: " + studentsInfo.getEmailAddress() + 
                "\nContact Number: " + studentsInfo.getContactNumber() + "\nProgram: " + program +
                "\nYear Level: " + yearLevel + "\nNumber of Units: " +
                numberOfUnits + "\nTuition Fee: " + getTuitionFee();
    }
}
