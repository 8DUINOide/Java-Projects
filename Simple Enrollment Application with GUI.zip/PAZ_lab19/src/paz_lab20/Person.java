/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paz_lab20;

/**
 *
 * @author CISCOLAB
 */
public class Person {
     private String name;
   private String contactNumber;
    private String emailAddress;
   

    public Person()
    {
        this.name = "Al Francis B. Paz";
        this.contactNumber = "09772153941";
        this.emailAddress= "afpaz@gbox.adnu.edu.ph";
    }
    public Person(String name, String emailAddress, String contactNumber)
    {
        this.name = name;
        this.contactNumber = contactNumber;  
        this.emailAddress = emailAddress;          
    }
    public void setName(String name)
    {
        this.name = name;
    }
        public void setContactNumber(String contactNumber)
    {
        this.contactNumber = contactNumber;
    }
    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }
    public String getName()
    {
        return name;
    }
    public String getEmailAddress()
    {
        return emailAddress;
    }
    public String getContactNumber()
    {
        return contactNumber;
    }
}
