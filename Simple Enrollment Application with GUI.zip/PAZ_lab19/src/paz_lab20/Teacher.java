/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paz_lab20;

/**
 *
 * @author CISCOLAB
 */
public class Teacher {
     private Person teachersInfo;
     private String specialization;
     private double perUnitRate;
     private double monthlySalary;
     private int numberOfUnits;
 public Teacher()
    {
        teachersInfo = new Person();
        specialization = "Math Teacher";
        perUnitRate = 1500.00;
        monthlySalary = 30000.00;
        numberOfUnits = 20;
    }
    public void setTeachersInfo(String name, String emailAddress, String contactNumber)
    {
        this.teachersInfo.setName(name);
        this.teachersInfo.setEmailAddress(emailAddress);
        this.teachersInfo.setContactNumber(contactNumber);
    }
    public void setSalary (String specialization, double perUnitRate, int numberOfUnits) {
        this.specialization = specialization;
        this.perUnitRate = perUnitRate;
        this.numberOfUnits = numberOfUnits;
    }
      public void setSpecialization(String specialization)
    {
        this.specialization = specialization;
    }
     public void setPerUnitRate(double perUnitRate)
    {
        this.perUnitRate = perUnitRate;
    }
      public void setMonthlySalary(double monthlySalary)
    {
        this.monthlySalary = monthlySalary;
    }
    public void setNumberOfUnits(int numberOfUnits)
    {
        this.numberOfUnits = numberOfUnits;
    }
   public String getSpecialization()
    {
        return specialization;
    }
    public double getPerUnitRate()
    {
        return perUnitRate;
    }
    public double getMonthlySalary()
    {
        monthlySalary = getPerUnitRate()*getNumberOfUnits();
        return monthlySalary;
    }
    public int getNumberOfUnits()
    {
        return numberOfUnits;
    }
    public String getTeachersInfo()
    {
        return teachersInfo.toString();
    }
    public String toString()
    {
           return "-------TEACHER INFORMATION------\n" + "Name: " + teachersInfo.getName() + "\nEmail Address: " + 
                   teachersInfo.getEmailAddress() + "\nContact Number: " + teachersInfo.getContactNumber() + 
                   "\nSpecialization: " + specialization + "\nNumber of Units: " + numberOfUnits + "\nPer Unit Rate: "
                   + perUnitRate + "\nMonthly Salary: " + getMonthlySalary() + "\n--------------------------------\n";
    }
}
  
